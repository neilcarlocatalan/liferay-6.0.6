/*
 * Copyright 2003 Sun Microsystems, Inc. All rights reserved.
 * SUN PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */

package com.sun.ts.tests.portlet.api.javax_portlet.ActionResponse;

/**
 * Common constants used in portlets and client.
 */
public interface CommonConstants {
    public static final String ERROR_MESSAGE = "errorMessage";
}
